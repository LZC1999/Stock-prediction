import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler
from tensorflow import keras
import matplotlib.pyplot as plt

# tr_x = data[0:2187] 10~18
# tr_y = ShenZhen20[0:2131] 10~18
# tr_x_2019 = data[2187:2431] 19
# tr_y_2019 = "" 19  .drop('交易日期', axis=1)

data = pd.read_csv("quarter_train_data.csv", encoding='gbk').drop('交易日期', axis=1).values
ShenZhen20 = pd.read_csv("沪深20指数-训练集.csv", encoding='gbk').drop('交易日期', axis=1).values

tr_x = data[0:1944]  # 10~17
tr_y = ShenZhen20[0:1944]  # 10~17

sc1 = MinMaxScaler()
sc2 = MinMaxScaler()
tr_x = sc1.fit_transform(tr_x)  # 10~17年数据
tr_y = sc2.fit_transform(tr_y.reshape(-1, 1))  # 10~17年数据

# 组织 网格数据
tmp = []
for i in range(57, 1944):  # 57是2010/13/31的下标
    tmp.append(tr_x[i - 53:i + 1])  # 前53天和今天作为输入
tr_x = tmp
tr_y = tr_y[57:1944]
tr_x = np.reshape(tr_x, (1887, 54, 9))
tr_y = np.reshape(tr_y, (1887,))

# 构建RRN神经网络（LSTM）
model = keras.Sequential([
    keras.layers.LSTM(units=100, activation='tanh', return_sequences=True, input_dim=tr_x.shape[-1],
                      input_length=tr_x.shape[1]),  # 神经元个数、输入维度、输入步长（滑动窗口）
    # keras.layers.Dropout(0.5),
    keras.layers.LSTM(units=50, activation='tanh'),  # 隐层
    # keras.layers.Dropout(0.3),
    # keras.layers.LSTM(units=60, activation='tanh'),  # 隐层
    keras.layers.Dense(units=1, activation='relu')  # 输出层
])

# 模型编译 RMsProp
model.compile(optimizer='adam', loss='mse', metrics=['mae'])

# 输入数据
model.fit(tr_x, tr_y, epochs=23, verbose=1, validation_split=0.1)

# 读入18年数据
tr_x_2018 = data[1891:2187]  # index = 1944是2018/1/2   index=1891是2017/10/18
tr_y_2018 = ShenZhen20[1891:2187]  # 因为网格化数据时要从 i=53 开始

sc3 = MinMaxScaler()
sc4 = MinMaxScaler()
# 归一化18年数据,tr_y_2018
#tr_x_2018 = sc3.fit_transform(tr_x_2018)
#tr_y_2018 = sc4.fit_transform(tr_y_2018)

# 组织 网格数据
x_valid, y_valid = [], []
for i in range(53, len(tr_x_2018)):
    x_valid.append(tr_x_2018[i - 53:i + 1])
    y_valid.append(tr_y_2018[i][0])

x_valid, y_valid = np.array(x_valid), np.array(y_valid)

# 预测18年数据
pre_2018 = model.predict(x_valid)
# 反归一化预测值
pre_2018 = sc4.inverse_transform(pre_2018)
# 反归一化真实值
y_valid = sc4.inverse_transform([y_valid])
loss = sum(abs(y_valid[0] - pre_2018.reshape(1, -1)[0])) / 243
print(f"MAE分数{loss}")

# 画图
plt.plot(pre_2018.reshape(1, -1)[0], 'b-', label='2018predict')
plt.plot(y_valid[0], 'r-', label='2018real')
plt.legend(loc='best')
plt.show()
'''# 另一种画图方式
plt.figure(figsize=(16,8))
dict_data = {
    'Predictions': pre_2018.reshape(1, -1)[0],
    'Close': y_valid[0]
}
data_pd = pd.DataFrame(dict_data)
plt.plot(data_pd[['Close', 'Predictions']])
plt.show()'''
'''# 预测2019年数据
tr_x_2019 = pd.DataFrame(train_data[2187:2431],
                         columns=["日开盘价", "日最高价", "日最低价", "日收盘价", "日个股交易股数",
                                  "日个股交易金额", "日个股流通市值", "日个股总市值", "日个股回报率", "交易日期",
                                  ]).drop('交易日期', axis=1)

tr_x_2019 = sc1.fit_transform(tr_x_2019)
tr_x_2019 = np.reshape(tr_x_2019, (244, 1, 9))
tr_y_2019 = model.predict(tr_x_2019)
print("2019年预测值：")
print("长度", len(tr_y_2019))
tr_y_2019 = np.reshape(tr_y_2019, (tr_y_2019.shape[0], 1))
tr_y_2019 = sc2.inverse_transform(tr_y_2019)
print(tr_y_2019)'''
