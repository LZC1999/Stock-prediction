# 按季度
'''
ShenZhen20 = pd.read_csv("沪深20指数-训练集.csv", encoding='gbk')
stock_picking = pd.read_csv('公司选择.csv', encoding="gb2312").values.tolist()
weight = pd.read_csv("季-15-PCA得到的权重.csv", encoding='gbk')
new_stock_prices = pd.read_csv("新个股价格.csv", encoding='gbk')

# 以截止日期为基准，对公司选择表进行分组,且每个季度的股票代码升序排序
tmp = []
new_stock_picking = []
for i in range(len(stock_picking)):
    if i == len(stock_picking) - 1:
        tmp.append(stock_picking[i])
        new_stock_picking.append(tmp)
    else:
        if stock_picking[i][1] == stock_picking[i + 1][1]:
            tmp.append(stock_picking[i])
        else:
            tmp.append(stock_picking[i])
            new_stock_picking.append(tmp)
            tmp = []

# 保存股票代码和截止日期信息,之后将添加加权和字段
stock_and_date = []
for i in new_stock_picking:
    tmp = []
    for j in i:
        tmp.append([j.pop(0), j.pop(0)])
    stock_and_date.append(tmp)

# 求出加权和
W_sum = []
for i in range(40):
    new_stock_picking[i] = StandardScaler().fit_transform(new_stock_picking[i])
    tmp = []
    for unit in new_stock_picking[i] * weight.values[i]:
        tmp.append(np.sum(unit))
    W_sum.append(tmp)

# 将加权和与股票代码和截至日期合并
good_stock = []
for i in range(40):
    tmp = []
    for j in range(len(W_sum[i])):
        tmp.append(stock_and_date[i][j] + [W_sum[i][j]])
    good_stock.append(tmp)


# 对加权和进行排序，找出每个季度的前20名公司
def takeThird(elem):
    return elem[2]


for i in range(len(good_stock)):
    good_stock[i].sort(key=takeThird, reverse=True)

for i in range(40):
    good_stock[i] = DataFrame(good_stock[i])
    good_stock[i] = list(good_stock[i][0])

new_stock_prices['交易日期x'] = new_stock_prices['交易日期'].apply(lambda x: time.mktime(time.strptime(x, "%Y/%m/%d")))
new_stock_prices['季度x'] = new_stock_prices['季度'].apply(lambda x: time.mktime(time.strptime(x, "%Y/%m/%d")))
# 若后期需要存季度数据，来这里找,一共2431天x
train_data = []
idx = 0

for unit in new_stock_prices.groupby(['季度x']):  # 按季度对数据分组
    for one_day in unit[1].groupby('交易日期x'):  # 按交易日期（天）对数据分组
        today = one_day[1]['交易日期'].tolist()[0]
        tmp = []
        for code in one_day[1].values:  # 一天内每个股票的数据
            if code[1] in good_stock[idx][0:20]:
                tmp.append(code[4:13])
        for g_code in good_stock[idx][20:]:  # 替补
            for code in one_day[1].values:
                if len(tmp) == 20:
                    break
                if code[1] == g_code:
                    tmp.append(code[4:13])
            if len(tmp) == 20:
                break
        day_data = np.mean(np.mat(tmp), 0).tolist()[0]  # tmp转np数组,转矩阵,取平均,转列表
        day_data.append(today)
        train_data.append(day_data)
    idx += 1

tr_x = pd.DataFrame(train_data,
                    columns=["日开盘价", "日最高价", "日最低价", "日收盘价", "日个股交易股数",
                             "日个股交易金额", "日个股流通市值", "日个股总市值", "日个股回报率", "交易日期",
                             ])#.drop('交易日期', axis=1)
tr_x.to_csv('quarter_train_data.csv')
print(tr_x)
exit()
'''

# 按天
'''
new_stock_prices = pd.read_csv("新个股价格.csv", encoding='gbk')
ShenZhen20 = pd.read_csv("沪深20指数-训练集.csv", encoding='gbk')
weight = pd.read_csv("天-9-PCA得到的权重.csv", encoding='gbk').values

new_stock_prices['交易日期x'] = new_stock_prices['交易日期'].apply(lambda x: time.mktime(time.strptime(x, "%Y/%m/%d")))
new_stock_prices['季度x'] = new_stock_prices['季度'].apply(lambda x: time.mktime(time.strptime(x, "%Y/%m/%d")))
X_data = new_stock_prices.drop(columns=['交易日期', '股票代码', '季度', 'index', '交易日期x', '季度x'], axis=1)

# 求出加权和
train_data = []
idx = 0
for unit in new_stock_prices.groupby('交易日期x'):
    today = unit[1]['交易日期'].tolist()[0]
    X_data = unit[1].drop(columns=['交易日期', '股票代码', '季度', 'index', '交易日期x', '季度x'], axis=1)
    X_data = StandardScaler().fit_transform(X_data)
    one_w_sum = (X_data * weight[idx]).sum(axis=1)  # 特征*权重
    unit[1]['加权和'] = one_w_sum
    good = unit[1].sort_values(by='加权和', ascending=False, axis=0)
    good.drop(columns=['交易日期', '股票代码', '季度', 'index', '交易日期x', '季度x', '加权和'], axis=1, inplace=True)
    day_data = np.mean(np.mat(good.values[0:20]), 0).tolist()[0]  # tmp转np数组,转矩阵,取平均,转列表
    day_data.append(today)
    train_data.append(day_data)

tr_x = pd.DataFrame(train_data[0:2187],
                    columns=["日开盘价", "日最高价", "日最低价", "日收盘价", "日个股交易股数",
                             "日个股交易金额", "日个股流通市值", "日个股总市值", "日个股回报率", "交易日期",
                             ]).drop('交易日期', axis=1)

'''