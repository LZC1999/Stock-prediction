import pandas as pd
import re

Stock_prices = pd.read_csv("个股价格.csv", encoding='gbk')
Company_information = pd.read_csv("公司信息.csv", encoding='gbk')
Quarterly_disclosure = pd.read_csv("季度披露.csv", encoding='gbk')
ShenZhen20 = pd.read_csv("沪深20指数-训练集.csv", encoding='gbk')

Date_list = pd.to_datetime(
    ["2010-03-31", "2010-06-30", "2010-09-30", "2010-12-31", "2011-03-31", "2011-06-30", "2011-09-30", "2011-12-31",
     "2012-03-31", "2012-06-30", "2012-09-30", "2012-12-31", "2013-03-31", "2013-06-30", "2013-09-30", "2013-12-31",
     "2014-03-31", "2014-06-30", "2014-09-30", "2014-12-31", "2015-03-31", "2015-06-30", "2015-09-30", "2015-12-31",
     "2016-03-31", "2016-06-30", "2016-09-30", "2016-12-31", "2017-03-31", "2017-06-30", "2017-09-30", "2017-12-31",
     "2018-03-31", "2018-06-30", "2018-09-30", "2018-12-31", "2019-03-31", "2019-06-30", "2019-09-30", "2019-12-31"]
)

"""数据处理第一阶段：把该删的数据给删了"""
# 删除公司信息中，证券简称带'ST'的公司
index = 0
for row in Company_information.itertuples():
    res = re.search(r'ST', row[2])
    if bool(res):
        Company_information.drop(index=index, axis=0, inplace=True)
    index += 1

# 保留季度披露中，行业代码为'I65','C27','I64'的数据，因为其他行业代码不是互联网和医学
Quarterly_disclosure = Quarterly_disclosure[Quarterly_disclosure['行业代码'].isin(['I65', 'C27', 'I64'])]

tmp = pd.merge(Company_information, Quarterly_disclosure, on=['股票代码'])

# 基于tmp，筛选三张表的股票代码
Stock_prices = Stock_prices[Stock_prices['股票代码'].isin(tmp['股票代码'])]
Quarterly_disclosure = Quarterly_disclosure[Quarterly_disclosure['股票代码'].isin(tmp['股票代码'])]
Company_information = Company_information[Company_information['股票代码'].isin(tmp['股票代码'])]

Quarterly_disclosure.drop(
    columns=['每股经营活动产生的现金流量净额',
             '归属于上市公司股东的每股净资产',
             '扣除非经常性损益后的加权平均净资产收益率'],
    axis=1, inplace=True)
Quarterly_disclosure.dropna(axis=0, how='any', inplace=True)


Quarterly_disclosure['截止日期'] = pd.to_datetime(Quarterly_disclosure['截止日期'])
Stock_prices['交易日期'] = pd.to_datetime(Stock_prices['交易日期'])
Stock_prices = Stock_prices.set_index('交易日期')


"""数据处理第二阶段：合并季度表和取了均值的个股表"""
Stock_mean = []
for unit in Stock_prices["2010-01-04":"2010-03-31"].groupby('股票代码').mean().itertuples():
    unit = list(unit)
    unit.append("2010-03-31")
    Stock_mean.append(unit)
for i in range(len(Date_list) - 1):
    tmp = Stock_prices[Date_list[i] + pd.Timedelta(days=1):Date_list[i + 1]].groupby('股票代码').mean()
    for unit in tmp.itertuples():
        unit = list(unit)
        unit.append(str(Date_list[i + 1])[0:10])
        Stock_mean.append(unit)

Stock_mean = pd.DataFrame(Stock_mean,
                          columns=["股票代码", "日开盘价", "日最高价", "日最低价", "日收盘价", "日个股交易股数", "日个股交易金额", "日个股流通市值",
                                   "日个股总市值", "日个股回报率", "截止日期"
                                   ])

index1 = []
for unit in Quarterly_disclosure.itertuples():
    unit = list(unit)
    index1.append(str(unit[1])[0:10] + "+" + str(unit[2]))
Quarterly_disclosure['index'] = index1



index2 = []
for unit in Stock_mean.itertuples():
    unit = list(unit)
    index2.append(str(unit[11])[0:10] + "+" + str(unit[1]))
Stock_mean['index'] = index2
Stock_picking = pd.merge(Stock_mean, Quarterly_disclosure, how='inner', on='index')
Stock_picking.rename(columns={'股票代码_x': '股票代码', '截止日期_x': "截止日期"}, inplace=True)
Stock_picking.drop(
    columns=["截止日期_y",
             "股票代码_y",
             "index",
             '行业代码'],
    axis=1, inplace=True)
# 移动列，为了好看而已

temp = Stock_picking.pop('截止日期')
Stock_picking.insert(1, '截止日期', temp)


"""数据处理第三阶段："""
# stock_picking = Stock_picking
stock_picking = pd.read_csv('公司选择.csv', encoding="gb2312")

# 转换为列表
stock_picking = stock_picking.values.tolist()

# 以截止日期为基准，对公司选择表进行分组,且每个季度的股票代码升序排序
tmp = []
new_stock_picking = []
for i in range(len(stock_picking)):
    if i == len(stock_picking) - 1:
        tmp.append(stock_picking[i])
        new_stock_picking.append(tmp)
    else:
        if stock_picking[i][1] == stock_picking[i + 1][1]:
            tmp.append(stock_picking[i])
        else:
            tmp.append(stock_picking[i])
            new_stock_picking.append(tmp)
            tmp = []

# 保存股票代码和截止日期信息，之后将添加加权和字段
stock_and_date = []
for i in new_stock_picking:
    tmp = []
    for j in i:
        tmp.append([j.pop(0), j.pop(0)])
    stock_and_date.append(tmp)

